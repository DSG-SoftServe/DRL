			/* Initialization of All Parallax Backgrounds */

			jQuery(document).ready(function(){
				//.parallax(xPosition, speedFactor, outerHeight) options:
				//xPosition - Horizontal position of the element
				//inertia - speed to move relative to vertical scroll. Example: 0.1 is one tenth the speed of scrolling, 2 is twice the speed of scrolling
				//outerHeight (true/false) - Whether or not jQuery should use it's outerHeight option to determine when a section is in the viewport
				var isMobile = {
					Android: function() {
						return navigator.userAgent.match(/Android/i);
					},
					BlackBerry: function() {
						return navigator.userAgent.match(/BlackBerry/i);
					},
					iOS: function() {
						return navigator.userAgent.match(/iPhone|iPad|iPod/i);
					},
					Opera: function() {
						return navigator.userAgent.match(/Opera Mini/i);
					},
					Windows: function() {
						return navigator.userAgent.match(/IEMobile/i);
					},
					any: function() {
						return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
					}
				};

				var testMobile = isMobile.any();
				
				if (testMobile == null)
				{
					
								jQuery(".bg1").parallax("50%", 0.2);
							
								jQuery(".bg2").parallax("50%", -0.04);
							
								jQuery(".bg3").parallax("50%", -0.035);
								
								jQuery(".bg4").parallax("50%", 0.2);
								
								jQuery(".post-855").parallax("50%", -0.4);
											}
			});